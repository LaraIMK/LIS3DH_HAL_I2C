/*
 * Driver_LIS3DH_hal.h
 *
 *  Created on: Mar 4, 2024
 *      Author: INTEKMEDICAL @LARA_CLARAMUNT_SERRA
 *
 *  Estructura del document:
 *  	1. PRE. (DATASHEET)
 *  		1.1. Includes
 *  		1.2. Defines
 *  		1.3. Registers
*  		2. FUNCIONS/ESTRUCTURES x COMUNICACIO LOW-LEVEL.
*  			2.1. Struct Acc
*  			2.2. Low-Level funcitons
*  		3. FUNCIONS x COMUNICACIO DIRECTE -> QUE UTILITZARAN LA LOW-LEVEL
*  			3.1. Inicialitzacio
*  			3.2. Adquisicio dades
*
*  		4. ESTRUCTURA BIT-FIELD DELS REGISTRES
*  			4.1. Control Registers
*  			4.2. Interrupt Registers
*  			4.3. Temperature Registers
*
*/

#ifndef INC_DRIVER_LIS3DH_HAL_H_
#define INC_DRIVER_LIS3DH_HAL_H_

/*
 * 1.1 INCLUDES
 */
#include "stm32h5xx_hal.h" // Necessari per utilitzar el HAL en I2C

/*
 * 1.2. DEFINES
 */
#define LIS3DH_I2C_ADDR			  (0x19 << 1) // SA0 = 0 -> 0x18=0b0011000, SA0 = 1 -> 0x19=0b0011001
#define LIS3DH_WHO_AM_I           0x0F        // L'utilitzarem per fer una comprovació de lectura al iniciar
#define LIS3DH_WHO_AM_I_VALUE	  0x33

/*
 * 1.3. REGISTERS
 */
#define LIS3DH_STATUS_REG_AUX     0x07
#define LIS3DH_OUT_ADC1_L         0x08
#define LIS3DH_OUT_ADC1_H         0x09
#define LIS3DH_OUT_ADC2_L         0x0A
#define LIS3DH_OUT_ADC2_H         0x0B
#define LIS3DH_OUT_ADC3_L         0x0C
#define LIS3DH_OUT_ADC3_H         0x0D
#define LIS3DH_CTRL_REG0          0x1E
#define LIS3DH_TEMP_CFG_REG       0x1F
#define LIS3DH_CTRL_REG1          0x20
#define LIS3DH_CTRL_REG2          0x21
#define LIS3DH_CTRL_REG3          0x22
#define LIS3DH_CTRL_REG4          0x23
#define LIS3DH_CTRL_REG5          0x24
#define LIS3DH_CTRL_REG6          0x25
#define LIS3DH_REFERENCE          0x26
#define LIS3DH_STATUS_REG         0x27
#define LIS3DH_OUT_X_L            0x28
#define LIS3DH_OUT_X_H            0x29
#define LIS3DH_OUT_Y_L            0x2A
#define LIS3DH_OUT_Y_H            0x2B
#define LIS3DH_OUT_Z_L            0x2C
#define LIS3DH_OUT_Z_H            0x2D
#define LIS3DH_FIFO_CTRL_REG      0x2E
#define LIS3DH_FIFO_SRC_REG       0x2F
#define LIS3DH_INT1_CFG           0x30
#define LIS3DH_INT1_SRC           0x31
#define LIS3DH_INT1_THS           0x32
#define LIS3DH_INT1_DURATION      0x33
#define LIS3DH_INT2_CFG           0x34
#define LIS3DH_INT2_SRC           0x35
#define LIS3DH_INT2_THS           0x36
#define LIS3DH_INT2_DURATION      0x37
#define LIS3DH_CLICK_CFG          0x38
#define LIS3DH_CLICK_SRC          0x39
#define LIS3DH_CLICK_THS          0x3A
#define LIS3DH_TIME_LIMIT         0x3B
#define LIS3DH_TIME_LATENCY       0x3C
#define LIS3DH_TIME_WINDOW        0x3D
#define LIS3DH_ACT_THS            0x3E
#define LIS3DH_ACT_DUR            0x3F




/*
 * 2.1. SENSOR STRUCT
 */

typedef struct {
	uint8_t dev_address;			//adreça del accelerometre
	I2C_HandleTypeDef *i2cHandle;   // Un punter al bus I2C utilitzat per a la comunicació
	float temp_C; 					// Temperatura en ºC. Decimal de 32 bits (per datasheet).
	float acc_ms2[3];             	// Acceleració [X, Y, Z] en [mg]== [(1000) * m/s2]. Es un float pq es un decimal de 32 bits (per datasheet).
									// En caso de quererlo en [g] -> ACC[g] = ACC[mg] / 1000;

}LIS3DH;

/*
 * 2.2. LOW-LEVEL FUNCTIONS
 * Nota: No li passo el i2c pq ho tindre a dins del Accelerometre (dev), pq a inicialització
 * l'haurè posat a dins seu
 */

HAL_StatusTypeDef LIS3DH_Read1Register( LIS3DH* dev, uint8_t reg, uint8_t* data);
HAL_StatusTypeDef LIS3DH_ReadRegisters( LIS3DH* dev, uint8_t reg, uint8_t* data, uint8_t length );
HAL_StatusTypeDef LIS3DH_WriteRegister( LIS3DH* dev, uint8_t reg, uint8_t* data);


/*
 * 3.1. INITIALISATION
 * Nota: Aquí, una de les coses que faré, serà incorporar la var i2c al struct del Accelerometre
 * de manera que les proximes vegades no haure de cridar al i2c sino a la variable Accelerometre (dev) :)
 */
uint8_t LIS3DH_Initialise( LIS3DH* dev , I2C_HandleTypeDef* i2cHandle, uint8_t dev_address);

// - FUNCIONS EXTRES
void LIS3DH_ConfigAllRegisters(LIS3DH* dev );
uint8_t LIS3DH_WriteAllRegisters(LIS3DH* dev );

/*
 * 3.2. DATA ACQUISITON
 */
HAL_StatusTypeDef LIS3DH_ReadTemperature( LIS3DH* dev );
HAL_StatusTypeDef LIS3DH_ReadAcceleration( LIS3DH* dev );
HAL_StatusTypeDef LIS3DH_ReadStatusReg( LIS3DH* dev );

/*
 * 4.1. CONTROL REGISTER bit-fields
 */
typedef struct {
    uint8_t reg_address; // Nuevo campo de dirección
    union {
        struct {
            const uint8_t _reserved : 7; // bit 0
            uint8_t SDO_PU_DISC : 1; // último bit
        } bit;
        uint8_t reg_value; // de registro
    };
} CTRL_REG0_Type;


typedef struct {
    uint8_t reg_address; // Nuevo campo de dirección
    union {
        struct {
            uint8_t Xen : 1; // bit 0
            uint8_t Yen : 1;
            uint8_t Zen : 1;
            uint8_t LPen : 1;
            uint8_t ODR : 4; // último bit
        } bit;
        uint8_t reg_value; // de registro
    };
} CTRL_REG1_Type;


typedef struct {
    uint8_t reg_address;
    union{
        struct {
            uint8_t HP_IA1 : 1; //bit 0
            uint8_t HP_IA2 : 1;
            uint8_t HPCLICK : 1;
            uint8_t FDS : 1;
            uint8_t HPCF : 2;
            uint8_t HPCM : 2;
        }bit;
        uint8_t reg_value;
    };
} CTRL_REG2_Type;


typedef struct {
    uint8_t reg_address;
    union {
        struct {
            const uint8_t _reserved : 1; //bit 0
            uint8_t I1_OVERRUN : 1;
            uint8_t I1_WTM : 1;
            uint8_t I1_321DA : 1;
            uint8_t I1_ZYXDA : 1;
            uint8_t I1_IA2 : 1;
            uint8_t I1_IA1 : 1;
            uint8_t I1_CLICK : 1;
        }bit;
        uint8_t reg_value;
    };
} CTRL_REG3_Type;


typedef struct {
    uint8_t reg_address;
    union {
        struct {
            uint8_t SIM : 1; //bit 0
            uint8_t ST : 2;
            uint8_t HR : 1;
            uint8_t FS : 2;
            uint8_t BLE : 1;
            uint8_t BDU : 1;
        }bit;
        uint8_t reg_value;
    };
} CTRL_REG4_Type;


typedef struct {
    uint8_t reg_address;
    union {
        struct {
            uint8_t D4D_INT2 : 1; //bit 0
            uint8_t LIR_INT2 : 1;
            uint8_t D4D_INT1 : 1;
            uint8_t LIR_INT1 : 1;
            const uint8_t _reserved : 2;
            uint8_t FIFO_EN : 1;
            uint8_t BOOT : 1;
        }bit;
        uint8_t reg_value;
    };
} CTRL_REG5_Type;


typedef struct {
    uint8_t reg_address;
    union {
        struct {
            const uint8_t _reserved : 1; //bit 0
            uint8_t INT_POLARITY : 1;
            const uint8_t _reserved1 : 1;
            uint8_t I2_ACT : 1;
            uint8_t I2_BOOT : 1;
            uint8_t I2_IA2 : 1;
            uint8_t I2_IA1 : 1;
            uint8_t I2_CLICK : 1;
        }bit;
        uint8_t reg_value;
    };
} CTRL_REG6_Type;



/*
 * 4.2. INTERRUPT REGISTER bit-fields
 */


typedef struct {
	uint8_t reg_address;
	union {
		struct {
			uint8_t XLIE : 1; //bit 0
			uint8_t XHIE : 1;
			uint8_t YLIE : 1;
			uint8_t YHIE : 1;
			uint8_t ZLIE : 1;
			uint8_t ZHIE : 1;
			uint8_t D6 : 1;
			uint8_t AOI : 1;
		}bit;
		uint8_t reg_value;
	};
} INT1_CFG_Type;


typedef struct {
	uint8_t reg_address;
	union {
		struct {
			uint8_t XLIE : 1; //bit 0
			uint8_t XHIE : 1;
			uint8_t YLIE : 1;
			uint8_t YHIE : 1;
			uint8_t ZLIE : 1;
			uint8_t ZHIE : 1;
			uint8_t D6 : 1;
			uint8_t AOI : 1;
		}bit;
		uint8_t reg_value;
	};
} INT2_CFG_Type;


typedef struct {
	uint8_t reg_address;
	union {
		struct {
			uint8_t XL : 1; //bit 0
			uint8_t XH : 1;
			uint8_t YL : 1;
			uint8_t YH : 1;
			uint8_t ZL : 1;
			uint8_t ZH : 1;
			uint8_t IA : 1;
			const uint8_t _reserved : 1;
		}bit;
		uint8_t reg_value;
	};
} INT1_SRC_Type;


typedef struct {
	uint8_t reg_address;
	union {
		struct {
			uint8_t XL : 1; //bit 0
			uint8_t XH : 1;
			uint8_t YL : 1;
			uint8_t YH : 1;
			uint8_t ZL : 1;
			uint8_t ZH : 1;
			uint8_t IA : 1;
			const uint8_t _reserved : 1;
		}bit;
		uint8_t reg_value;
	};
} INT2_SRC_Type;


typedef struct {
	uint8_t reg_address;
	union {
		struct{
			uint8_t THS : 7;  // bit0
			const uint8_t _reserved : 1;
		}bit;
		uint8_t reg_value;
	};
}INT1_THS_Type;


typedef struct {
	uint8_t reg_address;
	union {
		struct{
			uint8_t THS : 7;  // bit0
			const uint8_t _reserved : 1;
		}bit;
		uint8_t reg_value;
	};
}INT2_THS_Type;


typedef struct {
	uint8_t reg_address;
	union {
		struct{
			uint8_t D : 7;  // bit0
			const uint8_t _reserved : 1;
		}bit;
		uint8_t reg_value;
	};
}INT1_DURATION_Type;


typedef struct {
	uint8_t reg_address;
	union {
		struct{
			uint8_t D : 7;  // bit0
			const uint8_t _reserved : 1;
		}bit;
		uint8_t reg_value;
	};
}INT2_DURATION_Type;


/*
 * 4.3. TEMPERATURE bit-fields
 */

typedef struct {
	uint8_t reg_address;
	union {
		struct{
			const uint8_t _reserved : 6;  // bit0
			uint8_t TEMP_EN : 1;
			uint8_t ADC_EN : 1;
		}bit;
		uint8_t reg_value;
	};
}TMP_CFG_REG_Type;

/*
 * 4.4. STATUS REGISTER bit-fields
 */

typedef struct {
	uint8_t reg_address;
	union {
		struct{
			uint8_t XDA : 1;  // bit0
			uint8_t YDA : 1;
			uint8_t ZDA : 1;
			uint8_t ZYXDA : 1;
			uint8_t XOR : 1;
			uint8_t YOR : 1;
			uint8_t ZOR : 1;
			uint8_t ZYXOR : 1;
		}bit;
		uint8_t reg_value;
	};
}STATUS_REG_Type;
extern STATUS_REG_Type STATUS_REG; 	// Al fer-la extern li estic dient al compilador: Hey compilador, STATUS_REG existe en algún otro archivo. No te preocupes por eso ahora,
 	 	 	 	 	 	 	 		// solo ten en cuenta que lo usaré aquí.
									// => MORALEJA. L'he de fer extern pq aixi des del main.c la podre utilitzar, pq al fer #import driver.h estare important tmb aquesta variable, la qual li
									// he dit que existeix pero que esta declarada en algun altre fitxer (driver.c en aquest cas)

/*
 * 4.5. REFERENCE REGISTER bit-fields
 */

typedef struct {
	uint8_t reg_address;
	union {
		struct{
			uint8_t REF : 8;
		}bit;
		uint8_t reg_value;
	};
}REFERENCE_Type;


/*
 * 4.6. STATUS REG AUX bit-fields
 */

typedef struct {
	uint8_t reg_address;
	union {
		struct{
			uint8_t DA1 : 1;  // bit0
			uint8_t DA2 : 1;
			uint8_t DA3 : 1;
			uint8_t DA321 : 1;
			uint8_t OR1 : 1;
			uint8_t OR2 : 1;
			uint8_t OR3 : 1;
			uint8_t OR321 : 1;
		}bit;
		uint8_t reg_value;
	};
}STATUS_REG_AUX_Type;
extern STATUS_REG_AUX_Type STATUS_REG_AUX;



#endif /* INC_DRIVER_LIS3DH_HAL_H_ */






































