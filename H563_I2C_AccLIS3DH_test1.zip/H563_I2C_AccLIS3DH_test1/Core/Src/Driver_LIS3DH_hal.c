/*
 * Driver_LIS3DH_hal.c
 *
 *  Created on: Mar 4, 2024
 *      Author: INTEKMEDICAL @LARA_CLARAMUNT_SERRA
 *
 *  Estructura del document:
 *  	1. LOW-LEVEL FUNCTIONS
 *  		- Read1Register()
 *  		- ReadRegisters()
 *  		- WriteRegister()
 *
 *  	2. FUNCIONS PPALS
 *  		2.1. INITIALISATION()
 *  		2.2. DATA ACQUISITON
 *  			   - ReadTemperature()
 *  			   - ReadAcceleration()
 * 			       - ReadStatusReg()
 *
 *  	3. FUNCIONS AUXILIAR DE INITIALISATION()
 * 				   - ConfigAllRegisters()
 * 				   - WriteAllRegisters()
 *
 */

#include "Driver_LIS3DH_hal.h"


// 1) CONTROL REG
CTRL_REG0_Type CTRL_REG0;
CTRL_REG1_Type CTRL_REG1;
CTRL_REG2_Type CTRL_REG2;
CTRL_REG3_Type CTRL_REG3;
CTRL_REG4_Type CTRL_REG4;
CTRL_REG5_Type CTRL_REG5;
CTRL_REG6_Type CTRL_REG6;
// 2) INTERRUPT REG
INT1_CFG_Type INT1_CFG;
INT2_CFG_Type INT2_CFG;
INT1_SRC_Type INT1_SRC;
INT2_SRC_Type INT2_SRC;
INT1_THS_Type INT1_THS;
INT2_THS_Type INT2_THS;
INT1_DURATION_Type INT1_DURATION;
INT2_DURATION_Type INT2_DURATION;
// 3) TEMPERATURE REG
TMP_CFG_REG_Type TMP_CFG_REG;
// 4) STATUS REG
STATUS_REG_Type STATUS_REG;
// 5) REFERENCE REG
REFERENCE_Type REFERENCE_REG;
// 6) STATUS AUXILIAR REG
STATUS_REG_AUX_Type STATUS_REG_AUX;



/*
 * 1. LOW-LEVEL FUNCTIONS
 */
HAL_StatusTypeDef LIS3DH_Read1Register( LIS3DH* dev, uint8_t reg, uint8_t* data){
	return HAL_I2C_Mem_Read(dev->i2cHandle, dev->dev_address, reg, I2C_MEMADD_SIZE_8BIT, data, 1, HAL_MAX_DELAY);
}
HAL_StatusTypeDef LIS3DH_ReadRegisters( LIS3DH* dev, uint8_t reg, uint8_t* data, uint8_t length ){
	return HAL_I2C_Mem_Read(dev->i2cHandle, dev->dev_address, reg, I2C_MEMADD_SIZE_8BIT, data, length, HAL_MAX_DELAY);
}
HAL_StatusTypeDef LIS3DH_WriteRegister( LIS3DH* dev, uint8_t reg, uint8_t* data){
	return HAL_I2C_Mem_Write(dev->i2cHandle, dev->dev_address, reg, I2C_MEMADD_SIZE_8BIT, data, 1, HAL_MAX_DELAY);
}

/*
 * 2.1. INITIALISATION
 */
uint8_t LIS3DH_Initialise( LIS3DH* dev , I2C_HandleTypeDef* i2cHandle, uint8_t dev_address){

	/* 1) Inicialitzo estructura de l'Accelerometre*/
	dev->i2cHandle = i2cHandle;
	dev->dev_address = dev_address;
	dev->acc_ms2[0] = 0.0f; //hem de posar la f pq sino em posaria un double per defecte (64bits) i nomes necessitem 32bits per obtenir cada registres d'acceleracio (per datasheet)
	dev->acc_ms2[1] = 0.0f;
	dev->acc_ms2[2] = 0.0f;
	dev->temp_C = 0.0f;

	/* 2.1) Faig comprovacio connexio i2c*/
	if (HAL_I2C_IsDeviceReady(dev->i2cHandle, dev->dev_address, 10, 3000) != HAL_OK){
		return 254;
	}

	/* 2.2) Faig comprovacio lectura amb el registre de proba WHO_AM_I*/
	uint8_t regLlegit = 0;
	if (LIS3DH_Read1Register(dev, LIS3DH_WHO_AM_I, &regLlegit) != HAL_OK ){
		return 253;
	}
	if (regLlegit != LIS3DH_WHO_AM_I_VALUE){
		return 252;
	}

	/* 3.1) Configuro Registres = Lligo adreces + DEFAULT VALOR */
	LIS3DH_ConfigAllRegisters(dev);

	/* 3.2) Write All Registers */
	LIS3DH_WriteAllRegisters(dev);

	/* 4) Configuració desitjada */

	CTRL_REG1.bit.LPen = 0;  /* Set High-Resolution Mode with 12 bit resol. */
	CTRL_REG4.bit.HR = 1;
	uint8_t ErrNum = (LIS3DH_WriteRegister(dev, CTRL_REG1.reg_address, &CTRL_REG1.reg_value) != HAL_OK );
	ErrNum += (LIS3DH_WriteRegister(dev, CTRL_REG4.reg_address, &CTRL_REG4.reg_value) != HAL_OK );

	CTRL_REG4.bit.BDU = 1; /* Enable Block Data Update. */
	ErrNum += (LIS3DH_WriteRegister(dev, CTRL_REG4.reg_address, &CTRL_REG4.reg_value) != HAL_OK );

	CTRL_REG1.bit.ODR = 0b0001; /* Set Output Data Rate to 1Hz. */
	ErrNum += (LIS3DH_WriteRegister(dev, CTRL_REG1.reg_address, &CTRL_REG1.reg_value) != HAL_OK );

	CTRL_REG4.bit.FS = 0b00 ; /* Set full scale to 2g. */
	ErrNum += (LIS3DH_WriteRegister(dev, CTRL_REG4.reg_address, &CTRL_REG4.reg_value) != HAL_OK );

	TMP_CFG_REG.bit.ADC_EN = 1;  /* Enable temperature sensor. */
	TMP_CFG_REG.bit.TEMP_EN = 1;
	ErrNum += (LIS3DH_WriteRegister(dev, TMP_CFG_REG.reg_address, &TMP_CFG_REG.reg_value) != HAL_OK );

	CTRL_REG1.bit.Xen = 1;          // Xaxis = enabled
	CTRL_REG1.bit.Yen = 1;		    // Yaxis = enabled
	CTRL_REG1.bit.Zen = 1;		    // Zaxis = enabled
	ErrNum += (LIS3DH_WriteRegister(dev, CTRL_REG1.reg_address, &CTRL_REG1.reg_value) != HAL_OK );

	return ErrNum;

}

/*
 * 2.2. DATA ACQUISITON
 */
HAL_StatusTypeDef LIS3DH_ReadTemperature( LIS3DH* dev ){

	/* 1) Llegeixo registres temperatura */
	uint8_t regData[2];
	HAL_StatusTypeDef status = LIS3DH_ReadRegisters(dev, TMP_CFG_REG.reg_address, regData, 2);

	/* 2) Converteixo registres a data temperatura
	 * -> freq.ADC = freq.ODR
	 * -> num.bits = 10 si esta en Normal o HR mode
	 * -> data: 2's complement and left-alligned  => 9 bits DATA
	 */
	uint16_t data_regTemp = ( ( (regData[0] << 8) | (regData[1]) ) >> 6 ) & 0x03FF;
	uint16_t mask = 0x0200;
	int16_t data_temp =  -(data_regTemp & mask) + (data_regTemp & (~mask));


	/* 3) Calculate the sensitivity for 10 bits based on the one for 8 bits given by the datasheet
	* -> Note1: Num.bits = 10 if it's in Normal or HR mode
	* -> Note2: Data: 2's complement and left-alligned => 9 bits DATA -> (Datasheet page 19)
	* -> Note3: Sensitivity = 1LSB/ºC for 8-bit data -> (Datasheet page 12)
	*        --> To calculate sensitivity for 10-bit data, knowing Sens=1digit/ºC with 8 bits 2's complement = 1 sign + 7 data, it means that:
	*            -128  -value8Bit-  128
	*              [XXXXXXXXXXXXXXXX] with sensitivity of 1digit/ºC means that temperature is:
	*             -128    -temp-    128
	*
	*           so it must coincide that for 10 bits 2's complement the temperature range is the same (-128 to 128ºC)
	*            -512 -value10Bit-  512
	*              [XXXXXXXXXXXXXXXX]
	*             -128    -temp-    128
	*
	*             --> Therefore, the sensitivity is 128/512 = 0.25 ºC/LSB
	*
	* 4) Calculate the final temperature :)
	* ==> TEMP [ºC] = LSB * Sensitivity10bits = LSB * (128/512) = LSB * 0.25 ºC/LSB
	* ==> I DON'T KNOW IF IT SHOULD BE ADDED + 25ºC OR NOT HAHAHAHAHAHA :S SO WE'LL TRY IT OUT
	*
	* FROM THE CODE:
	* dev->temp_C = data_temp * 0.25f + 25.0f;
	*
	*/


	dev->temp_C = data_temp*0.25f; //+25?

	return status;
}

HAL_StatusTypeDef LIS3DH_ReadAcceleration( LIS3DH* dev){

	/* 1) Llegeixo registres X_L,X_H,Y_L,Y_H,Z_L,Z_H */
	uint8_t regData[6] = {0};
	HAL_StatusTypeDef status = LIS3DH_ReadRegisters(dev, LIS3DH_OUT_X_L, regData, 6);

	/* 2) Junto registres dels axis
	 * Nota1: Tenir en compte numero de bits de data segons si es HR o Normal -> cas HR = 12 bits
	 * Nota2: La data es 2's coplement per donar signe (S), per tant: numero bits data = data -1 -> 11 bits (D) :)
	 * Nota3: és left-allignemnt per tant tots els bits de data estaran a l'esquerra
	 * =>                  [Axis_High]       [Axis_Low]
	 * => Tinc:       S D D D D D D D D | D D D D 0 0 0 0
	 * => Obj final:  0 0 0 0 S D D D D | D D D D D D D D
	 */
	uint16_t data_RegAcc[3] = {0};
	data_RegAcc[0] = (   (  (regData[1] << 8) | (regData[0])  )  >> 4 ) & 0x0FFF; // Xaxis
	data_RegAcc[1] = (   (  (regData[3] << 8) | (regData[2])  )  >> 4 ) & 0x0FFF; // Yaxis
	data_RegAcc[2] = (   (  (regData[5] << 8) | (regData[4])  )  >> 4 ) & 0x0FFF; // Zaxis

	/* 3) Passo de 2's complement a un enter amb signe (signed)
	 * Nota1: Creo mascara tal que coincideixi amb el MSB de data = 12e bit en HR mode -> mask = 0x0800;
	 * (Haviem vist que el bit de signe S està a la posicio 12:  0 0 0 0 S D D D D | D D D D D D D D )
	 */
	uint16_t mask = 0x0800;
	int16_t data_acc[3] = {0};
	data_acc[0] = -(data_RegAcc[0] & mask) + (data_RegAcc[0] & (~mask));
	data_acc[1] = -(data_RegAcc[1] & mask) + (data_RegAcc[1] & (~mask));
	data_acc[2] = -(data_RegAcc[2] & mask) + (data_RegAcc[2] & (~mask));

	/* 4) Obtain the relationship g/LSB = [m/s2] / [LSB] = SENSITIVITY
	*      -2g     -range-     +2g         RANGE[m/s2] = [g]
	*        [XXXXXXXXXXXXXXXX]
	*       0    -num.comb-   2^12bits     NUM.COMB[LSB]
	*      -2048      0       2048         value
	*
	* => SENSITIVITY = [g]/[LSB] = RANGE / NUM.COMB = 4 / 2^12 = 0.0009765 g/LSB
	* => SENSITIVITY = [mg]/[LSB] = (2 / 2^11) * 1000  = 0.9765 == 1 mg/LSB (=> THIS IS WHAT APPEARS IN THE DATASHEET pg.9)
	* Which is the same as looking at it in the following way, without the sign bit, so it would be:
	*
	*       0      -range-     +2g         RANGE[m/s2]
	*        [XXXXXXXXXXXXXXXX]
	*       0    -num.comb-   2^11bits     NUM.COMB[LSB]
	*       0                  2048        value
	*
	* => SENSITIVITY = [g]/[LSB] = RANGE / NUM.COMB = 2 / 2^11 = 0.0009765 g/LSB
	* => SENSITIVITY = [mg]/[LSB] = (2 / 2^11) * 1000 = 0.9765 == 1 mg/LSB (=> THIS IS WHAT APPEARS IN THE DATASHEET pg.9)
	*
	* 5) Obtain ACC in [g] or [mg]
	*       => ACC[mg] = data_acc[LSB] * SENSITIVITY
	*       => ACC[mg] = data_acc[LSB] * 1 [mg/LSB]
	*       => ACC[g] = ACC[mg] / 1000;
	*
	* FROM THE CODE:
	* float sensitivity = ( 2 / 2048 ) * 1000;
	* float sensitivity = 1.0f;
	*
	*/

	float sensibilitat = ( 2.0f / 2048.0f ) * 1000.0f; // [mg/digit] per high-resolution mode & FS=+-2g --> (Application Notes pagina 10)
	dev->acc_ms2[0] = data_acc[0] * sensibilitat; //AccX in [mg]
	dev->acc_ms2[1] = data_acc[1] * sensibilitat; //AccY in [mg]
	dev->acc_ms2[2] = data_acc[2] * sensibilitat; //AccZ in [mg]

	dev->acc_ms2[0] = dev->acc_ms2[0] * (9.81f) ; //AccX in [mili m/s2]
	dev->acc_ms2[1] = dev->acc_ms2[1] * (9.81f) ; //AccY in [mili m/s2]
	dev->acc_ms2[2] = dev->acc_ms2[2] * (9.81f) ; //AccZ in [mili m/s2]

	return status;
}


HAL_StatusTypeDef LIS3DH_ReadStatusReg( LIS3DH* dev ){
	HAL_StatusTypeDef status = LIS3DH_Read1Register(dev, STATUS_REG.reg_address, &STATUS_REG.reg_value);
	return status;
}

/*
 * 3. FUNCIONS AUXILIAR de INITIALISE
 */

void LIS3DH_ConfigAllRegisters(LIS3DH* dev ){
	// 1) CONTROL REGISTER address i inicialitzacio per defecte
	CTRL_REG0.reg_address = LIS3DH_CTRL_REG0;
	CTRL_REG0.reg_value = 0b00010000;

	CTRL_REG1.reg_address = LIS3DH_CTRL_REG1;
	CTRL_REG1.reg_value = 0b00000111;

	CTRL_REG2.reg_address = LIS3DH_CTRL_REG2;
	CTRL_REG2.reg_value = 0x00;

	CTRL_REG3.reg_address = LIS3DH_CTRL_REG3;
	CTRL_REG3.reg_value = 0x00;

	CTRL_REG4.reg_address = LIS3DH_CTRL_REG4;
	CTRL_REG4.reg_value = 0x00;

	CTRL_REG5.reg_address = LIS3DH_CTRL_REG5;
	CTRL_REG5.reg_value = 0x00;

	CTRL_REG6.reg_address = LIS3DH_CTRL_REG6;
	CTRL_REG6.reg_value = 0x00;

	// 2) INTERRUPT REGISTERS inicialitzacio i address
	INT1_CFG.reg_address = LIS3DH_INT1_CFG;
	INT1_CFG.reg_value = 0x00;

	INT2_CFG.reg_address = LIS3DH_INT2_CFG;
	INT2_CFG.reg_value = 0x00;

	INT1_THS.reg_address = LIS3DH_INT1_THS;
	INT1_THS.reg_value = 0x00;

	INT2_THS.reg_address = LIS3DH_INT2_THS;
	INT2_THS.reg_value = 0x00;

	INT1_DURATION.reg_address = LIS3DH_INT1_DURATION;
	INT1_DURATION.reg_value = 0x00;

	INT2_DURATION.reg_address = LIS3DH_INT2_DURATION;
	INT2_DURATION.reg_value = 0x00;

	// -Read-Only. Pero igualment m'interessa definir la seva estructura per despres poder llegir facilment :)
	// -Encanvi els OUT_X_L i semblants no cal que crei estructura bit-field pq tots els bits em donen info del eix, no te bit-field :)
	INT1_SRC.reg_address = LIS3DH_INT1_SRC;  //Read-Only

	INT2_SRC.reg_address = LIS3DH_INT2_SRC;  //Read-Only

	// 3) TEMPERATURE REGISTERS inicialitzacio i address
	TMP_CFG_REG.reg_address = LIS3DH_TEMP_CFG_REG;
	TMP_CFG_REG.reg_value = 0x00;

	// 4) STATUS REGISTER - Read-Only
	STATUS_REG.reg_address = LIS3DH_STATUS_REG; //Read-Only

	// 5) REFERENCE REGISTER
	REFERENCE_REG.reg_address = LIS3DH_REFERENCE;
	REFERENCE_REG.reg_value = 0x00;

	// 6) STATUS AUX REGISTER inicialitizacio i address
	STATUS_REG_AUX.reg_address = LIS3DH_STATUS_REG_AUX; // Read-Only

}


uint8_t LIS3DH_WriteAllRegisters(LIS3DH* dev ){

	/* Faig Write de la configuracio desitjada dels registres */

	uint8_t ErrNum = 0;
	// 1) CONTROL REGISTERS write
	if (LIS3DH_WriteRegister(dev, CTRL_REG0.reg_address, &CTRL_REG0.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	if (LIS3DH_WriteRegister(dev, CTRL_REG1.reg_address, &CTRL_REG1.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	if (LIS3DH_WriteRegister(dev, CTRL_REG2.reg_address, &CTRL_REG2.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	if (LIS3DH_WriteRegister(dev, CTRL_REG3.reg_address, &CTRL_REG3.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	if (LIS3DH_WriteRegister(dev, CTRL_REG4.reg_address, &CTRL_REG4.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	if (LIS3DH_WriteRegister(dev, CTRL_REG5.reg_address, &CTRL_REG5.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	if (LIS3DH_WriteRegister(dev, CTRL_REG6.reg_address, &CTRL_REG6.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	if (LIS3DH_WriteRegister(dev, CTRL_REG6.reg_address, &REFERENCE_REG.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	// 2) INTERRUPT REGISTERS write
	if (LIS3DH_WriteRegister(dev, INT1_CFG.reg_address, &INT1_CFG.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	if (LIS3DH_WriteRegister(dev, INT2_CFG.reg_address, &INT2_CFG.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	if (LIS3DH_WriteRegister(dev, INT1_THS.reg_address, &INT1_THS.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	if (LIS3DH_WriteRegister(dev, INT2_THS.reg_address, &INT2_THS.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	if (LIS3DH_WriteRegister(dev, INT1_DURATION.reg_address, &INT1_DURATION.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	if (LIS3DH_WriteRegister(dev, INT2_DURATION.reg_address, &INT2_DURATION.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	// 3) TEMPERATURE REGISTERS write
	if (LIS3DH_WriteRegister(dev, TMP_CFG_REG.reg_address, &TMP_CFG_REG.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	// 4) STATUS REGISTERS - no te cap write register
	// 5) REFERENCE REGISTERS write
	if (LIS3DH_WriteRegister(dev, REFERENCE_REG.reg_address, &REFERENCE_REG.reg_value) != HAL_OK ){
		ErrNum ++;
	}
	// 6) STATUS AUX REGISTERS - no te cap write register


	return ErrNum;
}





